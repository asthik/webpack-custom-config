import React from 'react';
import ReactDOM from 'react-dom';
import './app.scss';

class App extends React.Component {
    render() {
        return (
            <p>Hello buddy</p>
        );
    }
}

export default App;

ReactDOM.render(<App/>, document.getElementById('root'));